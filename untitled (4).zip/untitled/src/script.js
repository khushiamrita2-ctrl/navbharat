// Navigation switching with smooth fade
const links = document.querySelectorAll(".nav-link");
const pages = document.querySelectorAll(".page");

links.forEach(link => {
  link.addEventListener("click", e => {
    e.preventDefault();

    // Reset nav links
    links.forEach(l => l.classList.remove("active"));
    link.classList.add("active");

    // Transition between sections
    pages.forEach(page => {
      if (page.classList.contains("active")) {
        page.classList.remove("active");
      }
    });

    const target = document.querySelector(link.getAttribute("href"));
    setTimeout(() => target.classList.add("active"), 100);
  });
});

// Popup Welcome message
window.addEventListener("load", () => {
  const popup = document.getElementById("welcome-popup");
  setTimeout(() => {
    popup.style.display = "none";
  }, 2000); // Disappears after 2 seconds
});
document.addEventListener("DOMContentLoaded", () => {
  const navLinks = document.querySelectorAll(".navbar a");
  const sections = document.querySelectorAll(".page");

  navLinks.forEach(link => {
    link.addEventListener("click", (e) => {
      e.preventDefault();

      // remove active from all links + sections
      navLinks.forEach(nav => nav.classList.remove("active"));
      sections.forEach(sec => sec.classList.remove("active"));

      // activate clicked link + its section
      link.classList.add("active");
      document.getElementById(link.dataset.section).classList.add("active");
    });
  });

  // Welcome popup
  setTimeout(() => {
    alert("Welcome to Navbharat!");
  }, 800);
});
